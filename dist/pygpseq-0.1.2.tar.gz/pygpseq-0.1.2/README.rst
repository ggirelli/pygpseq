pyGPSeq
=======================

A Python package that provides tools to analyze images of GPSeq samples.

Sample script are available showing the code for single runs and batch runs.

Read the documentation in ``docs/_build/html`` for more details.

Build package
---

Build docs
---
