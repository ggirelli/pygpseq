# -*- coding: utf-8 -*-

from joblib import Parallel, delayed
import multiprocessing
import os
import time

from matplotlib.backends.backend_pdf import PdfPages
import matplotlib.pyplot as plt
import numpy as np

from .. import const
from ..tools import path as pt, io as iot, plot, stat as stt, string as st

from .series import Series

class Condition(iot.ioInterface):
	"""docstring for condition"""

	# Class-bound attributes
	__version__ = const.VERSION
	# Basic attributes
	path = '.'
	name = ''

	# Series file attributes
	ext = '.tif'

	# Series regexp
	reg = '^(?P<channel_name>[^/]*)'
	reg += '\.(?P<channel_str>channel[0-9]+)'
	reg += '\.(?P<series_str>series[0-9]+)'
	reg += '(?P<ext>\.tif)$'

	# Wrapped series
	series = []

	def __init__(self, path, main = None, **kwargs):
		"""
		@param:
		 - path <string> path to the condition folder
		 - main <pyGPSeq.main> main wrapper (opt)
		"""

		# If required, inherit from `main` wrap
		if None != main:
			logpath = main.logpath
			super(Condition, self).__init__(path = logpath, append = True)
			self.ext = main.ext
			self.verbose = main.verbose
			self.reg = main.reg
		else:
			super(Condition, self).__init__()

		# Save input parameters
		self.path = pt.add_trailing_slash(os.path.abspath(path))
		self.name = self.path[:len(self.path) - 1].split('/')
		self.name = self.name[len(self.name) - 1]
		self.printout('Initializing condition: "' + self.name + '"', 0)

		# Select condition's series
		self.series = pt.select_files(self.path, self.ext)
		self.series = pt.select_series(self.series, self.reg).items()
		self.printout('Found ' + str(len(self.series)) + ' series...', 1)

		# Instantiate series
		self.series = [list(ds) for ds in self.series]
		[self.series[i].append(i + 1) for i in range(len(self.series))]
		self.series = [Series(s, condition = self) for s in self.series]

	def find_nuclei(self, **kwargs):
		""" Segment current condition. """

		# Get default number of cores
		if not 'ncores' in kwargs.keys():
			ncores = 1
		else:
			ncores = kwargs['ncores']

		# Suffix for output
		if not 'suffix' in kwargs.keys():
			suffix = ''
		else:
			suffix = st.add_leading_dot(kwargs['suffix'])

		# Check plotting
		if not 'plotting' in kwargs.keys():
			kwargs['plotting'] = True

		# Check number of cores
		if ncores > multiprocessing.cpu_count():
			ncores = multiprocessing.cpu_count()
			msg = 'Decreased core number to maximum allowed: %i' % ncores
			msg += '\nPlease, don\'t ask for the impossible... ಠ_ಠ'
			self.printout(msg, -1)

		# Add necessary options
		kwargs = self.adjust_options(**kwargs)

		# Segment every series in the condition
		self.printout('Current condition: "' + self.name + '"...', 0)
		self.series = Parallel(n_jobs = ncores)(
			delayed(find_series_nuclei)(self, i, **kwargs)
			for i in range(len(self.series)))

	def adjust_options(self, **kwargs):
		"""
		Adjusts options to be passed to the Series class.
		Adds the following kawrgs:
		 - cond_name <string> condition wrapper name
		 - out_dir <string> output directory
		"""

		kwargs['cond_name'] = self.name

		return(kwargs)

	def get_nuclei(self):
		""" Returns a list of the nuclei in the condition. """
		nuclei = []
		for s in self.series:
			nuclei.extend(s.nuclei)
		return(nuclei)

	def single_threshold_nuclei(self, data, sigma, xlab = None, **kwargs):
		"""
		Selects a single-feature nuclear threshold.

		@param:
		 - data <numpy.array> single column nuclear data
		 - xlab <string> x-label (opt)
		"""

		# Start building output
		t = {'data' : data}

		# Calculate density
		t['density'] = stt.calc_density(t['data'], sigma = sigma)

		# Identify range
		args = [t['density']['x'], t['density']['y']]
		t['fwhm_range'] = stt.get_fwhm(*args)

		# Add plot features
		if None != xlab:
			t['xlab'] = xlab
		else:
			t['xlab'] = 'x'
		t['ylab'] = 'Density'
		np.set_printoptions(precision = 3)
		t['title'] = str(np.array([float(x) for x in t['fwhm_range']]))

		# Output
		return(t)

	def multi_threshold_nuclei(self,
		cond_name, seg_type, data, sigma, nsf,
		font_size, out_dir, wspace = None, hspace = None, **kwargs):
		"""
		Plot density with FWHM range and select rows in that range.
		Features used for the selection based on nsf.
		Return the thresholded nuclear data.

		@param:
		 - seg_type <pyGPSeq.const> segmentation type
		 - data <numpy.array> nuclear data
		 - sigma <float> sigma for smoothing and covariance calculation
		 - xsteps <int> density distribution curve precision (opt)
		 - nsf <[int]> list of features to use for nuclear selection
		"""

		# Set output suffix
		if not 'suffix' in kwargs.keys():
			suffix = ''
		else:
			suffix = st.add_leading_dot(kwargs['suffix'])

		# Check plotting
		if not 'plotting' in kwargs.keys():
			kwargs['plotting'] = True

		fig = plt.figure()
		suptitle = 'Automatic nuclei threshold for condition "'
		if self.name in kwargs['cdescr'].keys():
			suptitle += kwargs['cdescr'][cond_name] + '"'
		else:
			suptitle += cond_name + '"'
		plt.suptitle(suptitle)

		# Setup subplots spacing
		if None == wspace:
			wspace = .4
		if None == hspace:
			hspace = .4
		plt.subplots_adjust(wspace = wspace, hspace = hspace)

		# Filter features
		sel_data = {}
		plot_counter = 1
		for nsfi in nsf:
			nsf_field = const.NSEL_FIELDS[nsfi]
			nsf_name = const.NSEL_NAMES[nsfi]
			self.printout('Filtering ' + nsf_name + '...', 2)
			plt.subplot(2, 2, plot_counter)
			sel_data[nsf_field] = self.single_threshold_nuclei(
				data = data[nsf_field], sigma = sigma,
				xlab = plot.get_nsf_label(nsfi, seg_type))
			plot.set_font_size(font_size)
			plot.density_with_range(new_figure = False, **sel_data[nsf_field])
			plot_counter += 1

		# General scatterplot
		plt.subplot(2, 2, 4)
		plot.set_font_size(font_size)
		plt.plot(data[const.NSEL_FIELDS[nsf[0]]],
			data[const.NSEL_FIELDS[nsf[1]]], ',k')
		plt.hold(True)

		# Select based on range
		self.printout('Selecting nuclei...', 2)
		f = lambda x, r: x >= r[0] and x <= r[1]
		for nsfi in nsf:
			nsf_field = const.NSEL_FIELDS[nsfi]
		
			# Identify nuclei in the FWHM range
			nsf_data = sel_data[nsf_field]
			nsf_data['sel'] = [f(i, nsf_data['fwhm_range'])
				for i in nsf_data['data']]
			sel_data[nsf_field] = nsf_data
		
		# Select those in every FWHM range
		nsfields = [const.NSEL_FIELDS[nsfi] for nsfi in nsf]
		selected = [sel_data[f]['sel'] for f in nsfields]
		g = lambda i: all([sel[i] for sel in selected])
		selected = [i for i in range(len(selected[0])) if g(i)]
		sub_data = data[selected]

		# Selected scatterplot
		plt.plot(sub_data[const.NSEL_FIELDS[nsf[0]]],
			sub_data[const.NSEL_FIELDS[nsf[1]]], ',r')
		plt.xlabel(plot.get_nsf_label(nsf[0], seg_type))
		plt.ylabel(plot.get_nsf_label(nsf[1], seg_type))
		title = 'Selected ' + str(len(selected)) + '/'
		title += str(len(sel_data[const.NSEL_FIELDS[nsf[0]]]['data']))
		title += ' nuclei.'
		plt.title(title)
		plt.ticklabel_format(style = 'sci', axis = 'x', scilimits = (0, 0))
		plt.ticklabel_format(style = 'sci', axis = 'y', scilimits = (0, 0))

		# Export plot
		self.printout('Exporting threshold plot...', 2)
		fname = out_dir + const.OUTDIR_PDF + self.name + '.threshold_summary'
		fname += suffix + '.pdf'
		if kwargs['plotting']: plot.export(fname, 'pdf')
		fname = out_dir + const.OUTDIR_PNG + self.name + '.threshold_summary'
		fname += suffix + '.png'
		if kwargs['plotting']: plot.export(fname, 'png')
		self.printout(title, 2)
		plt.close(fig)

		# Output
		return(selected)

	def analyze_nuclei(self, **kwargs):
		"""
		Export current condition nuclei.

		@parma:
		 - sigma <float> sigma for smoothing and covariance calculation (opt)
		"""
		
		# CHECK PARAMS =========================================================

		# Get default number of cores
		if not 'ncores' in kwargs.keys():
			ncores = 1
		else:
			ncores = kwargs['ncores']

		# Set output suffix
		if not 'suffix' in kwargs.keys():
			suffix = ''
		else:
			suffix = st.add_leading_dot(kwargs['suffix'])

		# Check plotting
		if not 'plotting' in kwargs.keys():
			kwargs['plotting'] = True

		# Check number of cores
		if ncores > multiprocessing.cpu_count():
			ncores = multiprocessing.cpu_count()
			msg = 'Decreased core number to maximum allowed: %i' % ncores
			msg += '\nPlease, don\'t ask for the impossible... ಠ_ಠ'
			self.printout(msg, -1)

		# Add necessary options
		self.printout('Current condition: "' + self.name + '"...', 0)
		kwargs = self.adjust_options(**kwargs)

		# Create condition nuclear data directory if necessary
		if not os.path.isdir(kwargs['out_dir']):
			os.mkdir(kwargs['out_dir'])

		# GET NUCLEAR DATA =====================================================

		# Retrieve nuclei
		nuclei = self.get_nuclei()

		# Check that the condition contains nuclei
		if 0 == len(nuclei):
			return(None)

		# Retrieve nuclei summaries
		self.printout('Retrieving nuclear summary...', 1)
		summary = np.zeros(len(nuclei),
			dtype = const.DTYPE_NUCLEAR_SUMMARY)
		for i in range(len(nuclei)):
			summary[i] = nuclei[i].get_summary()

		# Filter nuclei
		msg = 'Filtering nuclei based on size, intensity and shape...'
		self.printout(msg, 1)
		selected = self.multi_threshold_nuclei(data = summary, **kwargs)
		
		# Apply selection
		summary = np.asarray([summary[i] for i in selected],
			dtype = const.DTYPE_NUCLEAR_SUMMARY)
		
		# Retrieve selected nuclei single-pixel data
		data_nested = Parallel(n_jobs = ncores)(
			delayed(get_series_nuclear_data)(self, summary, sidx, **kwargs)
			for sidx in list(set(summary['s'])))

		# Un-nest nuclear data
		data = []
		[data.extend(nested) for nested in data_nested]

		# Assemble into a single array
		self.printout('Merging into a single table...', 1)
		merged = np.zeros(sum([d.shape[0] for d in data]),
			dtype = const.DTYPE_NUCLEAR_DATA)
		currpos = 0
		for d in data:
			merged[currpos:(currpos + d.shape[0])] = d
			currpos = currpos + d.shape[0]

		# Remove rows with no DNA signal
		self.printout('Removing pixels without DNA signal...', 1)
		self.printout('Identifying pixels...', 2)
		toKeep = np.where(merged['dna'] != 0)[0]
		nToRemove = len(merged) - len(toKeep)
		if not 0 == nToRemove:
			merged = merged[toKeep]
			msg = 'Removed %i pixels without DNA signal...' % nToRemove
			self.printout(msg, 2)

		# PLOT =================================================================

		# EVERY PIXEL ----------------------------------------------------------

		# Produce profile plot
		self.printout('Generating profiles...', 1)
		profiles = self.make_profiles(merged, len(data), **kwargs)

		# Export single profile study
		self.printout('Studying single-pixel behaviour...', 1)
		self.check_single_pixels(merged, profiles, **kwargs)

		# Export single-condition plot
		self.printout('Exporting profiles...', 1)

		# Mean/median/mode profile plot
		fig = plot.single_condition_profiles(profiles, n_nuclei = len(data),
			**kwargs)
		plot.single_condition_profiles(profiles, n_nuclei = len(data),
			yfield = 'median', new_figure = False, **kwargs)
		plot.single_condition_profiles(profiles, n_nuclei = len(data),
			yfield = 'mode', new_figure = False, **kwargs)

		# Add legend
		plt.subplot(3, 2, 1)
		plt.legend(labels = ['mean', 'median', 'mode'],
			bbox_to_anchor = (0., 1.12, 1., .102), loc = 3,
			ncol = 2, mode = "expand", borderaxespad = 0.)

		# Export PDF
		fname = kwargs['out_dir'] + const.OUTDIR_PDF + self.name
		fname += '.profiles' + suffix + '.pdf'
		if kwargs['plotting']: plot.export(fname, 'pdf')

		# Export PNG
		fname = kwargs['out_dir'] + const.OUTDIR_PNG + self.name
		fname += '.profiles' + suffix + '.png'
		if kwargs['plotting']: plot.export(fname, 'png')

		# Close figure
		plt.close(fig)

		# PARTIAL VOLUME -------------------------------------------------------
		if const.AN_3D == kwargs['an_type']:
			part = merged[np.where(merged['part'] == 1)]
			
			# Produce partial nucleus profile plots
			msg = 'Generating partial profiles ['
			msg += str(kwargs['part_n_erosion']) + ']...'
			self.printout(msg, 1)

			# Store partial profile in the output
			profiles['part'] = self.make_profiles(part, len(data), **kwargs)

			# Export single profile study for partial volume
			msg = 'Studying single-pixel behaviour'
			msg += ' on partial volume [' + str(kwargs['part_n_erosion']) + ']'
			msg += '...'
			self.printout(msg, 1)
			supcomm = ' [partial volume ' + str(kwargs['part_n_erosion']) + ']'
			self.check_single_pixels(part, profiles['part'], partial = True,
				supcomm = supcomm, **kwargs)

			# Export partial nucleus single-condition plot
			title = 'partial_volume ' + str(kwargs['part_n_erosion'])
			fig = plot.single_condition_profiles(profiles['part'],
				n_nuclei = len(data), title_comment = title, **kwargs)
			plot.single_condition_profiles(profiles['part'],
				n_nuclei = len(data), yfield = 'median', title_comment = title,
				new_figure = False, **kwargs)
			plot.single_condition_profiles(profiles['part'],
				n_nuclei = len(data), yfield = 'mode', title_comment = title,
				new_figure = False, **kwargs)

			# Add legend
			plt.subplot(3, 2, 1)
			plt.legend(labels = ['mean', 'median', 'mode'],
				bbox_to_anchor = (0., 1.12, 1., .102), loc = 3,
				ncol = 2, mode = "expand", borderaxespad = 0.)

			# Export PDF
			fname = kwargs['out_dir'] + const.OUTDIR_PDF + self.name
			fname += '.profiles.part' + suffix + '.pdf'
			if kwargs['plotting']: plot.export(fname, 'pdf')

			# Export PNG
			fname = kwargs['out_dir'] + const.OUTDIR_PNG + self.name
			fname += '.profiles.part' + suffix + '.png'
			if kwargs['plotting']: plot.export(fname, 'png')

			# Close figure
			plt.close(fig)

		# Output
		self.printout('', 0)
		return((profiles, summary, merged))

	def check_single_pixels(self, indata, profiles, partial = None,
		supcomm = None, **kwargs):
		"""
		Produces single pixel behaviour study plot.

		@param:
		 - indata <np.array> single-pixel table, const.DTYPE_NUCLEAR_DATA
		 - profiles <dict{np.array}> smoothened and raw profiles (I ~ d)
		 - supcomm <string> a comment to be add to the plot main title
		"""

		# CHECK PARAMS =========================================================

		# Set output suffix
		if not 'suffix' in kwargs.keys():
			suffix = ''
		else:
			suffix = st.add_leading_dot(kwargs['suffix'])

		# Partial volume data
		if None == partial:
			partial = False

		# Check plotting
		if not 'plotting' in kwargs.keys():
			kwargs['plotting'] = True

		# Output file pointers
		fname = kwargs['out_dir'] + const.OUTDIR_PDF
		out_png = kwargs['out_dir'] + const.OUTDIR_PNG
		out_png += self.name + '.pixel_study.'
		if partial:
			fname += self.name + '.pixel_study.part' + suffix + '.pdf'
		else:
			fname += self.name + '.pixel_study' + suffix + '.pdf'
		if kwargs['plotting']: pp = PdfPages(fname)

		# PREPARE DATA =========================================================
		
		# Setup data for plotting
		dna = indata['dna'].astype('float')
		rat = indata['sig'] / dna
		pltitems = [
			('DNA channel...', indata['dna'], 'DNA [a.u.]', 'dna'),
			('Signal channel...', indata['sig'], 'Signal [a.u.]', 'sig'),
			('Signal/DNA ratio...', rat[rat != np.inf], 'Signal/DNA', 'ratio')
		]

		# PLOT =================================================================

		# Set plot super title
		if self.name in kwargs['cdescr'].keys():
			suptitle = 'Analysis "' + kwargs['cdescr'][self.name] + '"'
		else:
			suptitle = 'Analysis "' + self.name + '"'
		if None != supcomm:
			suptitle += supcomm
		suptitle += ' [' + str(kwargs['an_type']) + ']'
		suptitle += ' [sigma = ' + str(kwargs['sigma']) + ']'
		suptitle += ' [nbins = ' + str(kwargs['nbins']) + ']'

		# Plot
		for (msg, y, ylab, lab) in pltitems:
			self.printout(msg, 2)

			# Actual plot
			fig = plot.single_pixel_study(indata[kwargs['dfield']],
				y, ylab, profiles[lab], partial = partial, **kwargs)
			plt.suptitle(suptitle)

			# Export PDF
			if kwargs['plotting']: plt.savefig(pp, format = 'pdf')

			# Export PNG
			if partial:
				fname = out_png + lab + '.part' + suffix + '.png'
			else:
				fname = out_png + lab + suffix + '.png'
			if kwargs['plotting']: plt.savefig(fname, format = 'png')

			# Close figure
			plt.close(fig)

		# Close file pointer
		if kwargs['plotting']: pp.close()

	def make_profiles(self, pdata, n_nuclei, **kwargs):
		"""
		Prepares profiles for plotting.

		@param:
		 - pdata <np.array> single-pixel data table, const.DTYPE_NUCLEAR_DATA
		 - n_nuclei <int> number of nuclei
		"""

		# Will contain the profiles
		profiles = {}

		# DNA profile
		self.printout('DNA profile...', 2)
		profiles['dna'] = stt.smooth_sparse_gaussian(
			pdata[kwargs['dfield']].tolist(), pdata['dna'].tolist(), **kwargs)

		# Signal profile
		self.printout('Signal profile...', 2)
		profiles['sig'] = stt.smooth_sparse_gaussian(
			pdata[kwargs['dfield']].tolist(), pdata['sig'].tolist(), **kwargs)

		# Ratio profile
		self.printout('Signal/DNA profile...', 2)
		rat = pdata['sig'] / pdata['dna'].astype('float')
		profiles['ratio'] = stt.smooth_sparse_gaussian(
			pdata[kwargs['dfield']][rat != np.inf].tolist(),
			rat[rat != np.inf].tolist(), **kwargs)

		# Save number of nuclei and condition name
		profiles['n'] = n_nuclei
		profiles['condition'] = self.name

		return(profiles)

	def export_nuclei(self, **kwargs):
		""" Export current condition nuclei. """

		# Set output suffix
		if not 'suffix' in kwargs.keys():
			suffix = ''
		else:
			suffix = st.add_leading_dot(kwargs['suffix'])

		# Add necessary options
		self.printout('Current condition: "' + self.name + '"...', 0)
		kwargs = self.adjust_options(**kwargs)

		# Create condition nuclear data directory if necessary
		if not os.path.isdir(kwargs['out_dir']):
			os.mkdir(kwargs['out_dir'])

		# Segment every series in the condition
		logs = [s.export_nuclei(**kwargs) for s in self.series]

		# Will contain the summaries
		summary = np.zeros(sum([i.shape[0] for i in logs]),
			dtype = const.DTYPE_NUCLEAR_SUMMARY)

		# Log counter
		c = 0
		for log in logs:
			# Merge logs
			summary[c:(c + log.shape[0]), :] = log

			# Increase log counter
			c += log.shape[0]
		
		# Export condition summary
		np.savetxt(kwargs['out_dir'] + 'summary' + suffix + '.csv',
			summary, delimiter = ',', comments = '',
			header = ",".join([h for h in summary.dtype.names]))

	def propagate_attr(self, key):
		""" Propagate attribute current value to every series. """
		for i in range(len(self.series)):
			self.series[i][key] = self[key]

	def __getitem__(self, key):
		""" Allow get item. """
		if key in dir(self):
			return(getattr(self, key))
		else:
			return(None)

	def __setitem__(self, key, value):
		""" Allow set item. """
		if key in dir(self):
			self.__setattr__(key, value)

def find_series_nuclei(self, i, **kwargs):
	""" Function for parallelized nuclear segmentation. """

	# Set series verbosity
	if kwargs['ncores'] != 1:
		self.series[i].verbose = False

	# Get starting time
	start_time = time.time()

	# Find nuclei
	self.series[i], log = self.series[i].find_nuclei(**kwargs)

	# Print log all at once
	time_msg = 'Took %s s.\n' % (round(time.time() - start_time, 3))
	if not 1 == kwargs['ncores']:
		log += iot.printout(time_msg, 1, False)
		self.printout(log, 0)
	else:
		self.printout(time_msg, 1)

	# Output
	return(self.series[i])

def get_series_nuclear_data(self, summary, sidx, **kwargs):
	""" Function for parallelized single-pixel nuclear data retrieval. """

	# Set series verbosity
	if kwargs['ncores'] != 1:
		self.series[sidx - 1].verbose = False
	else:
		self.series[sidx - 1].verbose = True

	# Get starting time
	start_time = time.time()

	# Setup starting message
	msg = 'Retrieving nuclear data from series #' + str(sidx) + '...'
	msg = iot.printout(msg, 1, verbose = False)

	# Get nuclei ids for current series
	ns = [i for i in range(summary.shape[0]) if summary['s'][i] == sidx]
	ns = summary['n'][ns]

	# Retrieve nuclear data
	data, log = self.series[sidx - 1].get_nuclei_data(ns, **kwargs)

	# Print log all at once
	time_msg = 'Took %s s.' % (round(time.time() - start_time, 3))
	if not 1 == kwargs['ncores']:
		log = msg + log
		log += iot.printout(time_msg, 2, False)
		self.printout(log, 0)
	else:
		self.printout(time_msg, 2)

	# Output
	return(data)
